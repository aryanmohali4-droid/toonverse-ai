# Required Images — Toonverse-AI

The code is already wired to use these images. If a file is missing, the
site falls back to a safe placeholder (gradient or icon) so nothing breaks —
but for the "real anime artwork" look, drop these files in with these exact
names and folders.

**Best source for these:** once your Replicate API key is working (see main
README), generate one image per slot below using Toonverse-AI's own
Generate screen, download it, rename it to match, and upload it here.
That makes it genuinely original AI art with zero copyright risk — the
same tool your users will use.

## 1. Hero image (Home page top banner)
- Path: `images/hero/anime-hero.jpg`
- Suggested prompt: "anime character portrait, dramatic lighting, warm sunset colors, detailed digital illustration"
- Aspect ratio: roughly 4:3 or wider (landscape). It gets cropped to fill the banner, face/important area should be centered or upper-center.

## 2. Category thumbnails (Explore Categories row)
All square (1:1), at least 200x200px:
- `images/categories/anime-girl.jpg`
- `images/categories/anime-boy.jpg`
- `images/categories/epic-scene.jpg`
- `images/categories/character.jpg`
- `images/categories/fantasy.jpg`
- `images/categories/chibi.jpg`

Each should visually represent its category (e.g. anime-girl.jpg = a
female anime character portrait).

## 3. History images
No setup needed — these fill in automatically. Every image a user
generates via the Create screen is saved with its real URL and shown
directly in History. This is already "real artwork" by design, since it's
literally what Replicate generated.

## How to add these on GitHub (mobile)
1. Open your repo, go into the `images/hero` folder (or `images/categories`)
2. Tap "Add file" → "Upload files"
3. Upload the image with the exact filename listed above
4. Commit changes
5. Refresh your live site — the placeholder is replaced automatically, no code changes needed
