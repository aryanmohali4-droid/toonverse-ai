# Toonverse AI — Setup Guide (Mobile se)

Yeh guide bilkul mobile browser se follow ho sakti hai. Koi laptop/PC nahi chahiye.

## Kya hai isme
- `index.html`, `style.css`, `script.js` — website ka frontend (jo user dekhta hai)
- `api/generate.js` — backend function jo Replicate AI ko call karta hai (yahi image banwata hai)

## Step 1: Replicate account banao aur API key lo
1. Mobile browser mein jao: **replicate.com**
2. Sign up karo (GitHub ya Google se login easy hai)
3. Account bante hi thoda free credit milta hai
4. Top-right profile icon → **API tokens** pe jao
5. Ek naya token banao, use **copy** karke kahin safe jagah paste kar lo (notes app mein) — yeh baad mein chahiye hoga

Cost samjho: Flux Schnell model bahut sasta hai — roughly $0.003 per image (yaani ₹0.25 ke aas-paas per image). Free credit se hi 100+ images test ho jayengi.

## Step 2: GitHub par account banao
1. Browser mein jao: **github.com**
2. Sign up karo (free hai)

## Step 3: Ye code GitHub par upload karo
1. GitHub par login karke **"New repository"** banao (naam do: `toonverse-ai`)
2. Repository ke andar **"Add file" → "Upload files"** pe click karo
3. Yeh saari files upload karo: `index.html`, `style.css`, `script.js`, aur `api` folder (jisme `generate.js` hai)
4. **"Commit changes"** dabao — files upload ho jayengi

Tip: agar folder upload na ho paaye, toh `api` folder manually banao GitHub ke "Create new file" option se — path mein likho `api/generate.js` aur andar content paste karo.

## Step 4: Vercel se deploy karo
1. Browser mein jao: **vercel.com**
2. **Sign up with GitHub** — isse Vercel aur GitHub connect ho jayenge
3. Dashboard mein **"Add New" → "Project"** pe click karo
4. Apna `toonverse-ai` repository dhundo aur **Import** karo
5. Deploy button dabao — 1-2 minute mein website live ho jayegi, ek link milega jaise `toonverse-ai.vercel.app`

## Step 5: API key ko Vercel mein add karo (zaroori step)
Yeh step na kiya toh image generate nahi hogi.

1. Vercel dashboard mein apne project ke andar jao
2. **Settings → Environment Variables** pe jao
3. Naam do: `REPLICATE_API_TOKEN`
4. Value mein woh token paste karo jo Step 1 mein copy kiya tha
5. Save karo
6. Ab **Deployments** tab mein jao aur latest deployment ko **Redeploy** karo (taaki naya token apply ho)

## Step 6: Test karo
1. Apni website ka link kholo (jaise `toonverse-ai.vercel.app`)
2. Koi prompt likho, style choose karo, "Generate" dabao
3. 10-20 second mein image ban jani chahiye

## Agar kuch na chale
- Image nahi ban rahi → Vercel ke **Deployments → Logs** mein dekho error kya hai, mostly API key sahi se add nahi hui hoti
- "Server not configured" error → matlab Step 5 miss ho gaya
- Slow generation → Flux Schnell fast hai, agar bahut slow lage toh Replicate account mein credit check karo

## Aage kya add karna hai (baad mein)
- Login/signup
- Free 2 image limit, uske baad premium
- Payment (Razorpay)
- Gallery page, tutorials page

Yeh sab abhi is basic version mein nahi hai — jaan-bujh kar simple rakha hai pehle taaki core feature (prompt → image) achhe se kaam kare.
